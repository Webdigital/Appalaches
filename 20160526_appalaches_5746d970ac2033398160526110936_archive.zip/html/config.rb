
css_dir = "css" # by Compass.app 
sass_dir = "sass" # by Compass.app 
images_dir = "img" # by Compass.app 
output_style = :compressed # by Compass.app 
relative_assets = true # by Compass.app 
line_comments = true # by Compass.app 
sass_options = {:debug_info=>true} # by Compass.app 
sourcemap = true # by Compass.app 